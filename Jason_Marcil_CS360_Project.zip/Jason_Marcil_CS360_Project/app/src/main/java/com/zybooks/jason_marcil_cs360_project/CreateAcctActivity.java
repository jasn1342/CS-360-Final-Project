package com.zybooks.jason_marcil_cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateAcctActivity extends AppCompatActivity {

    EditText username, password, repassword;
    Button createacctbtn;
    Button btnlogin;
    DBHelper myDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_acct);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        repassword = (EditText) findViewById(R.id.repassword);

        createacctbtn = (Button) findViewById(R.id.createacctbtn);
        btnlogin = (Button) findViewById(R.id.btnlogin);

        myDB = new DBHelper(this);

        createacctbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();
                if (user.equals("") || pass.equals("") || repass.equals("")) {
                    Toast.makeText(CreateAcctActivity.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass.equals(repass)) {
                        Boolean userCheckResult = myDB.checkusername(user);
                        if (userCheckResult == false) {
                            Boolean regResult = myDB.insertData(user, pass);
                            if (regResult == true) {
                                Toast.makeText(CreateAcctActivity.this, "Registration Successful. \n Return to Login Page", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(CreateAcctActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(CreateAcctActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(CreateAcctActivity.this, "Password not matching.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLoginActivity();
            }
        });
    }

    public void openLoginActivity() {
        Intent int1 = new Intent(this, LoginActivity.class);
        startActivity(int1);
    }
}
