package com.zybooks.jason_marcil_cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    EditText name_input, amount_input;
    Button add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        name_input = findViewById(R.id.name_input);
        amount_input = findViewById(R.id.amount_input);
        add_button = findViewById(R.id.addbtn);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperInventory myDB = new DBHelperInventory(AddActivity.this);
                myDB.addItem(name_input.getText().toString().trim(),
                        Integer.valueOf(amount_input.getText().toString().trim()));
            }
        });
    }
}